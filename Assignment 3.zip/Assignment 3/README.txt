Assignment 3 Submission by : 
Huzefa Dargahwala (hydargah@indiana.edu)
Rahul Pasunuri (rahupasu@indiana.edu)

Question 1 : 
The solution is in the file Solution1.py, output is in the lowermost portion of the file added as a comment

Question 3 : 
Open file 80daysTagged.txt to view solution.

